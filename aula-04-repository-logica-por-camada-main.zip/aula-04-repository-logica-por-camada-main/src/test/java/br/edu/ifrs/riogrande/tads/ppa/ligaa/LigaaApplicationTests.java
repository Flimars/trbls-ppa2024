package br.edu.ifrs.riogrande.tads.ppa.ligaa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LigaaApplicationTests {

	@Test
	void contextLoads() {
	}

}
