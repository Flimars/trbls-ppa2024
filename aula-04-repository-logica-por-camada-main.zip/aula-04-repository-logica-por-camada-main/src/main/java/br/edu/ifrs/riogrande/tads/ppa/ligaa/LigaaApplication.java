package br.edu.ifrs.riogrande.tads.ppa.ligaa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LigaaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LigaaApplication.class, args); 
	}

}
